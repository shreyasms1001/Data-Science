import sqlite3

def fetch_students():
    """Fetch students from the database and calculate their total scores."""
    conn = sqlite3.connect("students.db")
    cursor = conn.cursor()

    # Fetch required student data
    cursor.execute("""
    SELECT id, name, cgpa, project_score, internships, extracurricular_score
    FROM students;
    """)
    students = cursor.fetchall()
    conn.close()

    # Calculate total scores
    student_scores = []
    for student in students:
        total_score = (
            student[2] * 4 +        # CGPA weight: 4
            student[3] * 2 +        # Project Score weight: 2
            student[4] * 1.5 +      # Internships weight: 1.5
            student[5] * 1          # Extracurricular Score weight: 1
        )
        student_scores.append((student[0], student[1], total_score))

    # Sort by total score in descending order
    return sorted(student_scores, key=lambda x: x[2], reverse=True)

def fetch_institutions():
    """Fetch institutions from the database, sorted by rank."""
    conn = sqlite3.connect("nirf_rankings.db")
    cursor = conn.cursor()

    # Fetch institution data
    cursor.execute("SELECT id, institution_name, rank FROM institutions ORDER BY CAST(rank AS INTEGER);")
    institutions = cursor.fetchall()
    conn.close()
    return institutions

def map_students_to_institutions(students, institutions):
    """Map students to institutions based on cutoff scores."""
    mappings = []
    num_institutions = len(institutions)
    students_per_institution = len(students) // num_institutions

    for i, institution in enumerate(institutions):
        start_idx = i * students_per_institution
        end_idx = start_idx + students_per_institution

        # Assign students within the range to the current institution
        for student in students[start_idx:end_idx]:
            mappings.append((student[1], student[2], institution[1], institution[2]))  # (Student Name, Total Score, Institution Name, Rank)

    # Handle remaining students if any
    remaining_students = students[num_institutions * students_per_institution:]
    for i, student in enumerate(remaining_students):
        institution = institutions[i % num_institutions]
        mappings.append((student[1], student[2], institution[1], institution[2]))

    return mappings

def display_mappings(mappings):
    """Display the student-to-institution mappings."""
    print("\nStudent-to-Institution Mappings:\n")
    for mapping in mappings:
        print(f"Student: {mapping[0]}, Total Score: {mapping[1]:.2f}, Institution: {mapping[2]}, Rank: {mapping[3]}")

# Main Execution
if __name__ == "__main__":
    # Fetch students and institutions
    students = fetch_students()
    institutions = fetch_institutions()

    # Perform mapping
    student_institution_mappings = map_students_to_institutions(students, institutions)

    # Display mappings
    display_mappings(student_institution_mappings)

    
    


